 <?php $__env->startSection('content'); ?>
<div class="w-full md:px-[2rem] my-2">
    <div
        class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-[2rem] max-w-sm mx-auto md:max-w-none md:mx-0"
    >
        <div
            class="w-full border shadow-md rounded-md py-[3rem] px-[2rem] bg-gray-500 bg-[url('../../../public/img/circle.svg')] bg-no-repeat bg-right"
        >
            <div class="flex flex-col justify-center items-center">
                <p>In Order</p>
                <?php if($orderMasuk != null): ?>
                <p><?php echo e($orderMasuk->orderIn); ?></p>
                <?php else: ?>
                <p>0</p>
                <?php endif; ?>
            </div>
        </div>
        <div
            class="w-full border shadow-md rounded-md py-[3rem] px-[2rem] bg-yellow-400 bg-[url('../../../public/img/circle.svg')] bg-no-repeat bg-right"
        >
            <div class="flex flex-col justify-center items-center">
                <p>New Order</p>
                <?php if($orderBaru != null): ?>
                <p><?php echo e($orderBaru->orderNew); ?></p>
                <?php else: ?>
                <p>0</p>
                <?php endif; ?>
            </div>
        </div>
        <div
            class="w-full border shadow-md rounded-md py-[3rem] px-[2rem] bg-red-400 bg-[url('../../../public/img/circle.svg')] bg-no-repeat bg-right"
        >
            <div class="flex flex-col justify-center items-center">
                <p>Cancel Order</p>
                <?php if($orderBatal != null): ?>
                <p><?php echo e($orderBatal->orderCancel); ?></p>
                <?php else: ?>
                <p>0</p>
                <?php endif; ?>
            </div>
        </div>
        <div
            class="w-full border shadow-md rounded-md py-[3rem] px-[2rem] bg-green-400 bg-[url('../../../public/img/circle.svg')] bg-no-repeat bg-right"
        >
            <div class="flex flex-col justify-center items-center">
                <p>Done Order</p>
                <?php if($orderSelesai != null): ?>
                <p><?php echo e($orderSelesai->orderDone); ?></p>
                <?php else: ?>
                <p>0</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="mt-[2rem] w-full border shadow-md">
        <table class="w-full border-b border-gray-400 rounded-md table-fixed text-left ">
            <thead class="border-b px-[2rem]">
                <tr>
                    <th class="py-2 px-3">No</th>
                    <th class="py-2 px-3">Name</th>
                    <th class="py-2 px-3">Phone</th>
                    <th class="py-2 px-3">E-mail</th>
                </tr>
            </thead>
            <tbody class="border-b px-[2rem]">
                <?php $no=1;
            ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">
                    <td class="py-2 px-3"><?php echo e($no++); ?></td>
                    <td class="py-2 px-3"><?php echo e($user->name); ?></td>
                    <td class="py-2 px-3"><?php echo e($user->phone); ?></td>
                    <td class="py-2 px-3"><?php echo e($user->email); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Lat\book-store\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>