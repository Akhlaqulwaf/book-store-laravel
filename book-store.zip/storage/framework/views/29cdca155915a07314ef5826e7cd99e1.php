
<?php $__env->startSection('content'); ?>
<div class="px-[2rem] md:px-[5rem]">
    <div class="py-[10rem]">
        <p class="text-center pb-5">Silahkan lakukan pembayaran</p>
        <div class="flex">
            <div class="mr-3 w-[15rem] py-2 rounded-sm bg-green-400">
                <div class="flex flex-col justify-center items-center text-white">
                    <?php $__currentLoopData = $rekening; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="w-full py-1 text-center border-b border-gray-500"><?php echo e($rek->nama_bank); ?></p>
                    <p class="py-1"><?php echo e($rek->atas_nama); ?></p>
                    <p class="py-1"><?php echo e($rek->no_rek); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <p class="text-center pt-5">Transfer sebesar Rp.<?php echo e(number_format($order->subtotal,2,',','.')); ?></p>
        <div class="flex justify-center items-center pt-3">
            <form action="<?php echo e(route('user.order.buktiBayar', ['id' => $order->id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="bukti_bayar" class="block text-sm text-gray-500">Upload bukti pembayaran</label>
                <input type="file" name="bukti_bayar" class="mt-2 rounded-md border border-gray-200 p-2.5" required>
                <div class="flex justify-end items-end mt-2">
                    <button type="submit" class="w-[5rem] py-2 bg-purple-400 rounded-md">upload</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Lat\book-store\resources\views/user/order/pembayaran.blade.php ENDPATH**/ ?>