 <?php $__env->startSection('content'); ?>
<div class="w-full p-7 md:px-[3rem] font-primary">
    <div class="px-0">
        <div class="border-b border-gray-400">Home/Product</div>
    </div>
    <div
        class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-[30px] max-w-sm mx-auto md:max-w-none md:mx-0 mt-5"
    >
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <div
                class="border shadow-md rounded-sm h-[200px] overflow-hidden mb-3 relative"
            >
                <a
                    href="<?php echo e(route('user.productDetail', ['id' => $product->id])); ?>"
                    class="w-[170px] h-full flex justify-center items-center mx-auto group transition"
                >
                    <div
                        class="w-[130px] h-full flex justify-center items-center mx-auto"
                    >
                        <img
                            src="<?php echo e(asset('storage/'.$product->image)); ?>"
                            class="max-w-[80px] group-hover:scale-110 duration-300"
                            alt=""
                        />
                    </div>
                </a>
            </div>
            <div>
                <a href=""><?php echo e($product->name); ?></a>
                <div class=""><?php echo e($product->category); ?></div>
                <div><?php echo e($product->harga); ?></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Lat\book-store\resources\views/user/product.blade.php ENDPATH**/ ?>