 <?php $__env->startSection('content'); ?>

<div class="w-full my-2">
    <div class="px-[2rem] w-full">
        <div class="flex justify-between items-center font-semibold">
            <h1 class="uppercase">New Order</h1>
        </div>
        <table class="w-full border text-[14px] shadow-md">
            <thead class="border-b">
                <tr>
                    <th class="px-3 py-3">No</th>
                    <th class="px-3 py-3">Invoice</th>
                    <th class="px-3 py-3">Pemesan</th>
                    <th class="px-3 py-3">Subtotal</th>
                    <th class="px-3 py-3">Metode Pembayaran</th>
                    <th class="px-3 py-3">Status Pesanan</th>
                    <th class="px-3 py-3">Action</th>
                </tr>
            </thead>
            <tbody class="border-b">
                <?php $no=1 ?> <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-3 py-3">
                        <?php echo e($no++); ?>

                    </td>
                    <th class="px-3 py-3">
                        <?php echo e($datas->invoice); ?>

                    </th>
                    <td class="px-3 py-3">
                        <?php echo e($datas->userName); ?>

                    </td>
                    <td class="px-3 py-3">
                        <?php echo e($datas->subtotal); ?>

                    </td>
                    <td class="px-3 py-3">
                        <?php echo e($datas->metode_pembayaran); ?>

                    </td>
                    <td class="px-3 py-3">
                        <?php echo e($datas->statusName); ?>

                    </td>
                    <td class="px-3 py-3">
                        <a
                            href="<?php echo e(route('admin.transaksi.detail', ['id' => $datas->id])); ?>"
                            class="font-medium text-white hover:underline w-[45px] h-[25px] bg-yellow-300 rounded-sm mr-2 flex justify-center items-center"
                            >Detail</a
                        >
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Lat\book-store\resources\views/admin/transaksi/pesananBaru.blade.php ENDPATH**/ ?>