 <?php $__env->startSection('content'); ?>

<div class="w-full px-[1rem] md:px-[2rem] my-3">
    <h1 class="uppercase font-semibold">Tambah Product</h1>
    <form
        method="POST"
        enctype="multipart/form-data"
        action="<?php echo e(route('admin.rekening.store')); ?>"
        class="text-[14px]"
    >
        <?php echo csrf_field(); ?>
        <div class="mb-6 mt-5">
            <label
                for="nama"
                class="block mb-2 text-sm font-medium text-gray-900"
                >Nama Bank</label
            >
            <input
                type="text"
                name="nama_bank"
                id="nama_bank"
                class="border w-full placeholder:text-[14px] border-gray-400 bg-gray-200 rounded-md focus:ring-0 focus:border-gray-600"
                placeholder="Nama Bank"
            />
            <?php $__errorArgs = ['nama_bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-6">
            <label
                for="atas_nama"
                class="block mb-2 text-sm font-medium text-gray-900"
                >Atas Nama</label
            >
            <input
                type="text"
                name="atas_nama"
                id="atas_nama"
                class="border w-full placeholder:text-[14px] border-gray-400 bg-gray-200 rounded-md focus:ring-0 focus:border-gray-600"
                placeholder="Atas Nama"
            />
            <?php $__errorArgs = ['atas_nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-6">
            <label
                for="no_rek"
                class="block mb-2 text-sm font-medium text-gray-900"
                >Nomer Rekening</label
            >
            <input
                type="text"
                name="no_rek"
                id="no_rek"
                class="border w-full placeholder:text-[14px] border-gray-400 bg-gray-200 rounded-md focus:ring-0 focus:border-gray-600"
                placeholder="Nomer rekening"
            />
            <?php $__errorArgs = ['no_rek'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button
            type="submit"
            class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        >
            Submit
        </button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Lat\book-store\resources\views/admin/rekening/tambah.blade.php ENDPATH**/ ?>