 <?php $__env->startSection('content'); ?>
<div class="w-full px-[1rem] md:px-[2rem] my-2">
    <div class="font-semibold">
        <h1 class="">Detail Pesanan</h1>
    </div>

    <div
        class="relative overflow-x-auto shadow-md sm:rounded-lg border mt-3 mb-4"
    >
        <table class="w-full text-[14px] text-left text-gray-700">
            <tr>
                <td class="py-1 w-[30%] px-4">Invoice</td>
                <td class="py-1">:</td>
                <td class="py-1"><?php echo e($order->invoice); ?></td>
            </tr>
            <tr>
                <td class="py-1 w-[30%] px-4">Metode Pembayaran</td>
                <td class="py-1">:</td>
                <td class="py-1"><?php echo e($order->metode_pembayaran); ?></td>
            </tr>
            <tr>
                <td class="py-1 w-[30%] px-4">Status Pesanan</td>
                <td class="py-1">:</td>
                <td class="py-1"><?php echo e($order->statusName); ?></td>
            </tr>
            <tr>
                <td class="py-1 w-[30%] px-4">Total</td>
                <td class="py-1">:</td>
                <td class="py-1">
                    <?php echo e(number_format($order->subtotal,2,',','.')); ?>

                </td>
            </tr>
            <tr>
                <td class="py-1 w-[30%] px-4">Phone</td>
                <td class="py-1">:</td>
                <td class="py-1"><?php echo e($order->phone); ?></td>
            </tr>
            <?php if($order->pesan != null): ?>
            <tr>
                <td class="py-1 w-[30%] px-4">Message</td>
                <td class="py-1">:</td>
                <td class="py-1"><?php echo e($order->pesan); ?></td>
            </tr>
            <?php endif; ?> <?php if($order->bukti_bayar != null): ?>
            <tr>
                <td class="py-1 w-[30%] px-4">Bukti Pembayaran</td>
                <td class="py-1">:</td>
                <td class="py-1">
                    <img
                        src="<?php echo e(asset('storage/'.$order->bukti_bayar)); ?>"
                        class="max-w-[5rem]"
                        alt=""
                    />
                </td>
            </tr>
            <?php endif; ?> <?php if($order->status_order_id == 2): ?>
            <tr>
                <td class="py-2 px-[1rem]">
                    <a
                        href="<?php echo e(route('admin.transaksi.tolak', ['id' => $order->id])); ?>"
                        class="py-3 px-5 bg-pink-500"
                    >
                        tolak</a
                    >
                    <a
                        href="<?php echo e(route('admin.transaksi.konfirmasi', ['id' => $order->id])); ?>"
                        class="py-3 px-5 bg-pink-500"
                        >konfirm</a
                    >
                </td>
            </tr>
            <?php endif; ?>
        </table>
    </div>
    <div class="font-semibold mt-5">
        <h1 class="">Detail Pesanan Product</h1>
    </div>

    <div class="relative overflow-x-auto border shadow-md sm:rounded-lg mt-3">
        <table class="w-full text-center text-[14px]">
            <thead class="border-b">
                <tr>
                    <th class="px-6 py-3">No</th>
                    <th class="px-6 py-3">Gambar</th>
                    <th class="px-6 py-3">Nama Produk</th>
                    <th class="px-6 py-3">Qty</th>
                    <th class="px-6 py-3">Total</th>
                </tr>
            </thead>
            <tbody class="border-b">
                <?php $nos=1 ?> <?php $__currentLoopData = $detailOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-6 py-4">
                        <?php echo e($nos++); ?>

                    </td>
                    <td class="px-6 py-4">
                        <img
                            src="<?php echo e(asset('storage/'. $datas->image)); ?>"
                            class="max-w-[50px] mx-auto"
                            alt=""
                        />
                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($datas->productName); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($datas->qty); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e(number_format($datas->qty * $datas->harga,2,',','.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Lat\book-store\resources\views/admin/transaksi/detail.blade.php ENDPATH**/ ?>