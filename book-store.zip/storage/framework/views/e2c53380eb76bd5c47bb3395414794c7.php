<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/admin/app.css','resources/js/admin/app.js']); ?>
        <title>Login</title>
    </head>
    <body>
        <div class="w-full flex flex-col justify-center items-center">
            <div
                class="w-[65vw] md:w-[35vw] px-[2rem] py-[1rem] shadow-md border font-primary absolute top-[3%]"
            >
                <div class="flex justify-center items-center">
                    <p
                        class="iconify text-[5rem] mr-2 cursor-pointer"
                        data-icon="mdi-book-open-variant"
                    ></p>
                </div>
                <form action="<?php echo e(route('register')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="block pb-1">name</label>
                        <input
                            type="text"
                            name="name"
                            value="<?php echo e(old('name')); ?>"
                            class="w-full border-gray-400 rounded-md focus:border-gray-300 focus:ring-0"
                        />
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="block pb-1">phone</label>
                        <input
                            type="number"
                            name="phone"
                            value="<?php echo e(old('phone')); ?>"
                            class="w-full border-gray-400 rounded-md focus:border-gray-300 focus:ring-0"
                        />
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="block pb-1">E-mail</label>
                        <input
                            type="email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            class="w-full border-gray-400 rounded-md focus:border-gray-300 focus:ring-0"
                        />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="block pb-1"
                            >Password</label
                        >
                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="w-full border-gray-400 rounded-md focus:border-gray-300 focus:ring-0"
                        />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="block pb-1"
                            >Confirm Password</label
                        >
                        <input
                            type="password"
                            name="password_confirmation"
                            class="w-full border-gray-400 rounded-md focus:border-gray-300 focus:ring-0"
                        />
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="w-full py-2 bg-gray-400 rounded-md">
                        Login
                    </button>
                    <div class="flex justify-end items-end py-2 text-[13px]">
                        <p class="mr-1">Sudah Punya akun?</p>
                        <a href="<?php echo e(route('login')); ?>" class="hover:underline hover:text-blue-400">Register</a>
                    </div>
                </form>
            </div>
        </div>
        <script src="//code.iconify.design/1/1.0.6/iconify.min.js"></script>
    </body>
</html>
<?php /**PATH D:\Laravel\Lat\book-store\resources\views/auth/register.blade.php ENDPATH**/ ?>